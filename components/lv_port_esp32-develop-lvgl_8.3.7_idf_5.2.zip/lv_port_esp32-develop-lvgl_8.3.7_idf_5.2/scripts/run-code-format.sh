astyle --options=code-format.cfg "../main/*.c"
astyle --options=code-format.cfg "../components/lvgl_esp32_drivers/*.c,*.h"
astyle --options=code-format.cfg "../components/lvgl_esp32_drivers/lvgl_tft/*.c,*.h"
astyle --options=code-format.cfg "../components/lvgl_esp32_drivers/lvgl_touch/*c,*.h"
