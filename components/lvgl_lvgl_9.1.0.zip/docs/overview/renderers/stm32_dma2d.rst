=========
DMA2D GPU
=========

API
---

:ref:`lv_gpu_stm32_dma2d`
