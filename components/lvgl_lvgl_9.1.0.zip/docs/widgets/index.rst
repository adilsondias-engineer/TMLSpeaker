.. _widgets:

=======
Widgets
=======

.. toctree::
    :maxdepth: 1

    obj
    arc
    animimg
    bar
    button
    buttonmatrix
    calendar
    chart
    colorwheel
    canvas
    checkbox
    dropdown
    image
    imagebutton
    keyboard
    label
    led
    line
    list
    menu
    msgbox
    roller
    scale
    slider
    span
    spinbox
    spinner
    switch
    table
    tabview
    textarea
    tileview
    win
