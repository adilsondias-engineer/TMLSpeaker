
Touchpad monkey example
-----------------------

.. lv_example:: others/monkey/lv_example_monkey_1
  :language: c

Encoder monkey example
----------------------

.. lv_example:: others/monkey/lv_example_monkey_2
  :language: c

Button monkey example
---------------------

.. lv_example:: others/monkey/lv_example_monkey_3
  :language: c
